# Update PfBDP1 Manuscript Deployment

## Summary

Rebuild the current `9hhc-enamine` manuscript, republish it at the existing
URL, and document update and takedown procedures in `README.md`.

## Changes

- Replace credential-bearing Git remotes with token-free URLs.
- Render the manuscript with Pixi.
- Copy only approved publication files into the website repository.
- Render the website and publish only the manuscript subdirectory.
- Document update, takedown, and restoration commands.

## Verification

- Confirm all six outputs exist and the HTML remains unlisted.
- Confirm staged changes contain no unrelated website files.
- Confirm the live page and downloads return HTTP 200.
- Confirm tracked files and Git remotes contain no credentials.

## Assumptions

- Generated publication files may exceed the normal two-file limit.
- The public page remains unlisted, not access-controlled.
- Bibliography and unrelated website files remain unchanged.
