# Publish manuscript and downloadable formats as an unlisted subpage

## Summary

Publish at:

`https://diallobakary4.github.io/manuscripts/pfbdp1-enamine/`

Keep the homepage unchanged. The HTML page offers PDF, DOCX, and MECA
downloads through Quarto's existing "Other Formats" panel.

## Published output

- `index.html`
- `index.pdf`
- `index.biorxiv.pdf`
- `supplement.pdf`
- `index.docx`
- `manuscript-meca.zip`
- Required figures, HTML libraries, and styles

Exclude standalone notebooks and intermediate LaTeX/JATS files.

## Implementation

- Remove credentials from both repositories' remote URLs.
- Render all required formats from the private manuscript repository.
- Set the final manuscript URL and disable the private repository link.
- Add `noindex, nofollow` metadata during unlisted review.
- Copy approved output to `docs/manuscripts/pfbdp1-enamine/`.
- Stage only that subdirectory and preserve unrelated homepage changes.
- Keep `publications.qmd` unchanged initially.

## Verification

- Preview the manuscript locally.
- Verify HTML and each download.
- Confirm the homepage remains unchanged.
- Confirm output contains no credentials.
- Inspect the final MECA archive before publishing.

## Publication and takedown

- Share the exact URL with colleagues while unlisted.
- Later, remove `noindex` and link it under a non-peer-reviewed section.
- To take down, delete only the manuscript subdirectory and push.

## Assumptions

- Full MECA contents are intentionally public.
- Downloadable formats require no authentication.
- Unlisted means undiscoverable, not access-controlled.
- Homepage publishes from `main/docs`.
