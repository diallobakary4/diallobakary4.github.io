
https://quarto.org/docs/authoring
@fetch https://quarto.org/docs/authoring



https://quarto.org/docs/authoring/front-matter.html

@fetch https://quarto.org/docs/authoring/front-matter.html




# THINGS TO REMEMBER

[index.qmd (line 131)](/home/bakary/projects/quarto-manuscript-template/index.qmd:131): made fig-alt single-line so Quarto parses {#fig-descriptors} correctly.
[_quarto.yml (line 5)](/home/bakary/projects/quarto-manuscript-template/_quarto.yml:5): limited render scope to index.qmd, so docs/plan files stop becoming manuscript notebooks.
[plan file (line 1)](/home/bakary/projects/quarto-manuscript-template/untitled:plan-fixQuartoCrossref.prompt.md:1): created per repo rule.





# find word citations
\(.*\)


