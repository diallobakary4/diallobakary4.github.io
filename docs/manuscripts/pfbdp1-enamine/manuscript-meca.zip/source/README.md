# Quarto Manuscript Template — Bakary Diallo

Personalized Quarto manuscript template for reproducible
cheminformatics and drug discovery research.

**Author:** Bakary Diallo
[![ORCID](https://img.shields.io/badge/ORCID-0000--0003--1741--2979-a6ce39)](https://orcid.org/0000-0003-1741-2979)

## Quick Start

```bash
# Clone and install
git clone git@github.com:diallobakary4/quarto-manuscript-template.git
cd quarto-manuscript-template
pixi install

# Preview
pixi run quarto preview index.qmd

# Render all formats
pixi run quarto render
```

## What's Inside

- `index.qmd` — manuscript with YAML front matter, executable
  Python (RDKit), citations, cross-refs, equations, tables
- `_quarto.yml` — project config (html, pdf, docx, jats)
- `references.bib` — BibTeX bibliography
- `pyproject.toml` — Python package metadata (Pixi managed)

## Customize

1. Edit `index.qmd` YAML header (title, authors, abstract)
2. Add your content in markdown + code cells
3. Update `references.bib` with your citations
4. Run `quarto render` or `quarto publish`

## Links

- [Quarto Manuscripts Docs](https://quarto.org/docs/manuscripts/)
- [RDKit](https://www.rdkit.org/)




## Ref

open edit in visual mode
/home/bakary/projects/quarto-manuscript-template/ref/ref.md
cite ctrl shift F8


#
figures/                          
tables/                           
data/
├── raw/                          
└── processed/ 

```bash
mkdir figures tables data data/raw data/processed -p
```


# Table 

https://quarto.org/docs/manuscripts/authoring/vscode.html#tables

| Name                 | Year   |
| -------------------- | ------ |
| Current              | 2021   |
| Teneguía             | 1971   |
| Nambroque            | 1949   |
| El Charco            | 1712   |
| Volcán San Antonio   | 1677   |
| Volcán San Martin    | 1646   |
| Tajuya near El Paso  | 1585   |
| Montaña Quemada      | 1492   |

: Recent historic eruptions on La Palma {#tbl-history}


# Figures

https://quarto.org/docs/manuscripts/authoring/vscode.html#static-figures
https://quarto.org/docs/authoring/cross-references.html?utm_source=chatgpt.com


![Map of La Palma](images/la-palma-map.png){#fig-map}


#| label: fig-timeline
#| fig-cap: Timeline of recent earthquakes on La Palma
#| fig-alt: An event plot of the years of the last 8 eruptions on La Palma.

@fig-timeline



As shown in @fig-workflow, the analysis consists of four stages.

![Computational analysis workflow](figures/workflow.png){
#fig-workflow
fig-alt="Diagram showing the four stages of the computational workflow"
width=80%
}

# cross ref
![alt text](image.png)

