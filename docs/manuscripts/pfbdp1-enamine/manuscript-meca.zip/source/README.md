# Quarto Manuscript Template — Bakary Diallo

Personalized Quarto manuscript template for reproducible
cheminformatics and drug discovery research.

**Author:** Bakary Diallo
[![ORCID](https://img.shields.io/badge/ORCID-0000--0003--1741--2979-a6ce39)](https://orcid.org/0000-0003-1741-2979)

## Quick Start

```bash
# Clone and install
git clone git@github.com:diallobakary4/quarto-manuscript-template.git
cd quarto-manuscript-template
pixi install

# Preview
pixi run quarto preview index.qmd

# Render all formats
pixi run quarto render
```

## What's Inside

- `index.qmd` — manuscript with YAML front matter, executable
  Python (RDKit), citations, cross-refs, equations, tables
- `_quarto.yml` — project config (html, pdf, docx, jats)
- `references.bib` — BibTeX bibliography
- `pyproject.toml` — Python package metadata (Pixi managed)

## Customize

1. Edit `index.qmd` YAML header (title, authors, abstract)
2. Add your content in markdown + code cells
3. Update `references.bib` with your citations
4. Run `quarto render` or `quarto publish`

## Publish the PfBDP1 manuscript

The live manuscript is served from `main/docs` in the sibling website
repository, not from this repository's `gh-pages` workflow:

<https://diallobakary4.github.io/manuscripts/pfbdp1-enamine/>

### Update

Run from this repository:

```bash
pixi run quarto render
site=../diallobakary4.github.io
target="$site/manuscripts/pfbdp1-enamine"
mkdir -p "$target"
cp _manuscript/index.{html,pdf,docx} "$target/"
cp _manuscript/{index.biorxiv,supplement}.pdf "$target/"
cp _manuscript/manuscript-meca.zip "$target/"
rsync -a --delete _manuscript/figures/ "$target/figures/"
rsync -a --delete _manuscript/site_libs/ "$target/site_libs/"
pixi run quarto render "$site"
git -C "$site" add -- manuscripts/pfbdp1-enamine
git -C "$site" add -- docs/manuscripts/pfbdp1-enamine
git -C "$site" diff --cached --stat
git -C "$site" commit -m "Update PfBDP1 manuscript"
git -C "$site" push origin main
```

Review the staged file list before committing. The page is public but contains
`noindex, nofollow`; the URL is unlisted, not access-controlled.

### Take down or restore

Removal stays recoverable through Git history:

```bash
site=../diallobakary4.github.io
git -C "$site" rm -r -- manuscripts/pfbdp1-enamine
git -C "$site" rm -r -- docs/manuscripts/pfbdp1-enamine
git -C "$site" diff --cached --stat
git -C "$site" commit -m "Take down PfBDP1 manuscript"
git -C "$site" push origin main

# Restore the removed page.
git -C "$site" revert <takedown-commit>
git -C "$site" push origin main
```

## Links

- [Quarto Manuscripts Docs](https://quarto.org/docs/manuscripts/)
- [RDKit](https://www.rdkit.org/)




## Ref

open edit in visual mode
/home/bakary/projects/quarto-manuscript-template/ref/ref.md
cite ctrl shift F8


#
figures/                          
tables/                           
data/
├── raw/                          
└── processed/ 

```bash
mkdir figures tables data data/raw data/processed -p
```


# Table 

https://quarto.org/docs/manuscripts/authoring/vscode.html#tables

| Name                 | Year   |
| -------------------- | ------ |
| Current              | 2021   |
| Teneguía             | 1971   |
| Nambroque            | 1949   |
| El Charco            | 1712   |
| Volcán San Antonio   | 1677   |
| Volcán San Martin    | 1646   |
| Tajuya near El Paso  | 1585   |
| Montaña Quemada      | 1492   |

: Recent historic eruptions on La Palma {#tbl-history}


# Figures

https://quarto.org/docs/manuscripts/authoring/vscode.html#static-figures
https://quarto.org/docs/authoring/cross-references.html?utm_source=chatgpt.com


![Map of La Palma](images/la-palma-map.png){#fig-map}


#| label: fig-timeline
#| fig-cap: Timeline of recent earthquakes on La Palma
#| fig-alt: An event plot of the years of the last 8 eruptions on La Palma.

@fig-timeline



As shown in @fig-workflow, the analysis consists of four stages.

![Computational analysis workflow](figures/workflow.png){
#fig-workflow
fig-alt="Diagram showing the four stages of the computational workflow"
width=80%
}

# cross ref
![alt text](image.png)
