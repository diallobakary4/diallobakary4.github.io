# Automate PfBDP1 Website Deployment

## Summary

Pushes to `9hhc-enamine` render the manuscript, update both website manuscript
directories, and push the website repository's `main` branch.

## Implementation

- Trigger on `9hhc-enamine` pushes and manual dispatch.
- Allow one deployment at a time; cancel superseded runs.
- Give the source `GITHUB_TOKEN` read-only contents permission.
- Install the locked Pixi environment and retain Quarto/TinyTeX setup.
- Render with `pixi run quarto render`.
- Check out `diallobakary4/diallobakary4.github.io` under `website/`.
- Synchronize `_manuscript` outputs to both:
  - `website/manuscripts/pfbdp1-enamine`
  - `website/docs/manuscripts/pfbdp1-enamine`
- Commit only changed output, include the source SHA, then push website `main`.
- Remove publishing to this repository's `gh-pages` branch.

## Authentication

- Revoke the exposed personal access token.
- Add a dedicated Ed25519 public key to the website repo as a writable deploy
  key.
- Store its private key in this repo as `WEBSITE_DEPLOY_KEY`.
- Never store credentials in Git URLs or repository files.

## Tests

- Run `pixi run quarto render` and verify required outputs.
- Manually dispatch once and confirm only both target directories change.
- Confirm the website commit and public URL.
- Rerun unchanged output and confirm no empty commit.
- Confirm render or push failure leaves the public page unchanged.

## Assumptions

- GitHub Pages publishes website `main/docs`.
- `9hhc-enamine` is the production manuscript branch.
- Direct synchronization replaces a website-wide render.
- Changes stay limited to this plan and the existing workflow.
