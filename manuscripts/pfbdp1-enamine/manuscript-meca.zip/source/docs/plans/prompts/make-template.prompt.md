I want to use this repository as a template there are two bran:

- 9hhc-enamine main

the main branch will be the one with all the requirements, all the template files and then all the new manuscripts wills be based on the main branch

- 9hhc-enamine: is a manuscript branch that i did use for a specific manuscript. it contains some changes that i would like to keep for the main.

I want you to list the files on 9hhc-enamine that I need to keep on the main branch

use these skills: /caveman /grill-with-docs /ponytail

@workspace\
#githubRepo #githubTextSearch #search #usages #codebase #sequentialthinking #textSearch #searchResults #doSearch #fileSearch #searchSyntax #resolve-library-id #get-library-docs #promptBoost #fetch #context7 Try best use skill from the mcp: my-mcp-server-aa8412b3 if useful use these skills:

/caveman

/grill-with-docs

/ponytail

/marimo-notebook

/marimo-pair-vscode

use these skills: /caveman /grill-with-docs /ponytail

@workspace\
#githubRepo #githubTextSearch #search #usages #codebase #sequentialthinking #textSearch #searchResults #doSearch #fileSearch #searchSyntax #resolve-library-id #get-library-docs #promptBoost #fetch #context7 Try best use skill from the mcp: my-mcp-server-aa8412b3 if useful use these skills: /caveman /grill-with-docs /ponytail

Respond in 200 words maximum