
diallobakary4/quarto-manuscript-template



best way to use this repo as template for manuscript

manuscript per branch 

or 

Manuscript per repo, is so how to quickly-easily share things in common?

use these skills:
/caveman
/grill-with-docs
/ponytail


@workspace  
#githubRepo #githubTextSearch
#search #usages #codebase   #sequentialthinking #textSearch #searchResults #doSearch #fileSearch #searchSyntax #resolve-library-id #get-library-docs #promptBoost #fetch 
#context7 
Try best use skill from the mcp: my-mcp-server-aa8412b3 if useful
use these skills:
/caveman
/grill-with-docs
/ponytail

Respond in maximum 10 lines of code; maximum 80 characters/line. Respond in 100 words maximum
